import{t as e,c as s}from"./format-BuON0pZi.js";function c(a,r){const t=e(a);return isNaN(r)?s(a,NaN):(r&&t.setDate(t.getDate()+r),t)}export{c as a};
